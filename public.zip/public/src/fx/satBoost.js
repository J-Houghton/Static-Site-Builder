export function driveSaturation(state){
    const el = document.getElementById('satBoost');
    if (!el) return;
    el.setAttribute('values', String(1 + state.specularSaturation));
}
  