// exports moved unchanged from your file
export const CONVEX_CIRCLE = { title: 'Convex Circle',  fn: x => Math.sqrt(1 - (1 - x) ** 2) };
export const CONVEX        = { title: 'Convex Squircle', fn: x => Math.pow(1 - Math.pow(1 - x, 4), 1/4) };
export const CONCAVE       = { title: 'Concave',         fn: x => 1 - CONVEX_CIRCLE.fn(x) };
export const LIP           = { title: 'Lip', fn: x => {
  const t = 6*x**5 - 15*x**4 + 10*x**3;
  const cv = CONVEX.fn(Math.min(1, x*2));
  const cc = CONCAVE.fn(x) + 0.1;
  return cv*(1 - t) + cc*t;
}};
export const SURFACE_FNS = { convex_circle: CONVEX_CIRCLE, convex_squircle: CONVEX, concave: CONCAVE, lip: LIP };
