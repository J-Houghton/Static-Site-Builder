// blob URL caching to avoid per-frame base64 work
export const cache = {
  dispKey:null, dispUrl:null, dispImg:null,
  maskKey:null, maskUrl:null,
  specKey:null, specUrl:null,
  rimKey:null,  rimUrl:null
}
export async function imageDataToBlobURL(imgData){
  const c = document.createElement('canvas');
  c.width = imgData.width; c.height = imgData.height;
  c.getContext('2d').putImageData(imgData, 0, 0);
  if (c.convertToBlob) {
    const blob = await c.convertToBlob({ type: 'image/png' });
    return URL.createObjectURL(blob);
  }
  const blob = await new Promise(r => c.toBlob(r, 'image/png'));
  return URL.createObjectURL(blob);
}
