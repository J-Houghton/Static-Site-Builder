import gsap from 'https://cdn.skypack.dev/gsap@3.13.0'
import Draggable from 'https://cdn.skypack.dev/gsap@3.13.0/Draggable'
gsap.registerPlugin(Draggable)
export function enableDrag(selector='.effect'){
    Draggable.create(selector, { type: 'x,y' });
}
